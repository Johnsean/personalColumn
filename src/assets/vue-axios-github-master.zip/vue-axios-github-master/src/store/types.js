/**
 * Created by superman on 17/2/16.
 * vuex types
 */

export const LOGIN = 'login';

export const LOGOUT = 'logout';

export const TITLE = 'title'